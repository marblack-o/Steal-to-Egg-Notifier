/**
 * Steal to Egg Notifier - Discord Bot
 * ------------------------------------
 * Detecta mensajes del bot SenZ V2 en el canal de huevos,
 * limpia el texto y lo deja listo para la app / notificaciones.
 *
 * Cómo usar:
 * 1. Copia .env.example → .env y pega tu token
 * 2. npm install
 * 3. npm start
 */

require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');

// ====== CONFIGURACIÓN ======
const CHANNEL_ID = '1544813161037963315';      // Canal de huevos
const SENZ_BOT_ID = '1409108089705332836';     // SenZ V2

// ====== Cliente ======
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // ¡Obligatorio!
  ],
  partials: [Partials.Channel],
});

// ====== Limpiador de mensajes (misma lógica que la app) ======
function cleanEggMessage(raw) {
  if (!raw) return null;

  // Extraer nombre
  const nameMatch = raw.match(/\*\*Egg:\*\*\s*([^\n\r]+)/i) || raw.match(/Egg:\s*([^\n\r]+)/i);
  const name = nameMatch ? nameMatch[1].trim() : 'Egg';

  // Wiki
  const wikiName = name.replace(/\s+/g, '_');
  const wikiUrl = `https://stealanegg.fandom.com/wiki/${encodeURIComponent(wikiName)}`;

  // Emoji ID (imagen)
  const emojiMatch = raw.match(/<:([a-zA-Z0-9_]+):(\d+)>/);
  const emojiId = emojiMatch ? emojiMatch[2] : null;
  const imageUrl = emojiId ? `https://cdn.discordapp.com/emojis/${emojiId}.png` : '';

  // Limpiar texto
  let text = raw.replace(/<:[a-zA-Z0-9_]+:\d+>/g, '');
  text = text.replace(/\*\*(.*?)\*\*/g, '*$1*');

  // Timestamp relativo simple
  text = text.replace(/<t:(\d+):R>/g, (_, ts) => {
    const diff = Math.floor(Date.now() / 1000) - parseInt(ts);
    if (diff < 60) return 'hace unos segundos';
    if (diff < 3600) return `hace ${Math.floor(diff / 60)} minutos`;
    return `hace ${Math.floor(diff / 3600)} horas`;
  });

  // Links
  text = text.replace(/\[Click Here\]\((https:\/\/www\.roblox\.com[^)]+)\)/gi, '$1');
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '$2');

  text = text
    .split('\n')
    .map(l => l.trim())
    .filter(l => l.length > 0)
    .join('\n');

  text = text
    .replace(/^\*?Egg:\*?\s*/im, '🥚 *Egg:* ')
    .replace(/^\*?Location:\*?\s*/im, '😈 *Location:* ')
    .replace(/^\*?Spawned:\*?\s*/im, '⏱ *Spawned:* ')
    .replace(/^\*?Money:\*?\s*/im, '💰 *Money:* ')
    .replace(/^\*?Recommended Speed:\*?\s*/im, '⚡ *Recommended Speed:* ')
    .replace(/^\*?Join Game:\*?\s*/im, '🎮 *Join Game:*\n');

  text = text.replace(/  +/g, ' ').trim();
  text += `\n🔍 *Wiki:*\n${wikiUrl}`;

  // Extra data
  const locationMatch = raw.match(/\*\*Location:\*\*\s*([^\n\r]+)/i) || raw.match(/Location:\s*([^\n\r]+)/i);
  const moneyMatch = raw.match(/\*\*Money:\*\*\s*([^\n\r]+)/i) || raw.match(/Money:\s*([^\n\r]+)/i);
  const speedMatch = raw.match(/\*\*Recommended Speed:\*\*\s*([^\n\r]+)/i) || raw.match(/Recommended Speed:\s*([^\n\r]+)/i);
  const joinMatch = raw.match(/\((https:\/\/www\.roblox\.com[^)]+)\)/i);

  return {
    name,
    location: locationMatch ? locationMatch[1].trim() : '',
    money: moneyMatch ? moneyMatch[1].trim() : '',
    speed: speedMatch ? speedMatch[1].trim() : '',
    join: joinMatch ? joinMatch[1] : '',
    wiki: wikiUrl,
    imageUrl,
    fullText: text,
    timestamp: Date.now(),
  };
}

// ====== Eventos ======
client.once('ready', () => {
  console.log(`✅ Bot conectado como ${client.user.tag}`);
  console.log(`👀 Escuchando canal: ${CHANNEL_ID}`);
  console.log(`🎯 Detectando bot: ${SENZ_BOT_ID} (SenZ V2)`);
});

client.on('messageCreate', async (message) => {
  // Ignorar otros canales
  if (message.channel.id !== CHANNEL_ID) return;

  // Solo mensajes de SenZ V2
  if (message.author.id !== SENZ_BOT_ID) return;

  // Evitar bots propios (por si acaso)
  if (message.author.id === client.user.id) return;

  console.log('\n🥚 ¡Huevo OP detectado!');
  console.log('────────────────────────────────');

  const cleaned = cleanEggMessage(message.content);

  if (!cleaned) {
    console.log('No se pudo limpiar el mensaje');
    return;
  }

  console.log(`Nombre : ${cleaned.name}`);
  console.log(`Location: ${cleaned.location}`);
  console.log(`Money  : ${cleaned.money}`);
  console.log(`Speed  : ${cleaned.speed}`);
  console.log('────────────────────────────────');
  console.log(cleaned.fullText);
  console.log('────────────────────────────────\n');

  // =====================================================
  // AQUÍ ES DONDE LUEGO MANDAREMOS A LA APP / ntfy / etc.
  // Por ahora solo lo muestra en consola.
  // =====================================================

  // Ejemplo futuro:
  // await sendToNtfy(cleaned);
  // await saveToJson(cleaned);
});

// ====== Login ======
const token = process.env.DISCORD_TOKEN;

if (!token) {
  console.error('❌ No se encontró DISCORD_TOKEN en el archivo .env');
  console.error('   Crea un archivo .env y pon: DISCORD_TOKEN=tu_token_aqui');
  process.exit(1);
}

client.login(token).catch(err => {
  console.error('❌ Error al conectar:', err.message);
  process.exit(1);
});
