# Steal to Egg Notifier – Bot de Discord

Bot oficial que detecta los mensajes de **SenZ V2** en el canal de huevos y los prepara para la app.

## Requisitos

- Node.js 18 o superior
- Token de tu bot de Discord
- Message Content Intent activado

## Instalación rápida

```bash
# 1. Entra a la carpeta
cd bot

# 2. Instala dependencias
npm install

# 3. Configura el token
cp .env.example .env
# Edita .env y pega tu token:
# DISCORD_TOKEN=tu_token_aqui

# 4. Arranca el bot
npm start
```

## Configuración importante

1. Ve a [Discord Developer Portal](https://discord.com/developers/applications)
2. Tu aplicación → **Bot**
3. Activa **MESSAGE CONTENT INTENT**
4. Guarda los cambios
5. Reinicia el bot

## Qué hace ahora

- Escucha solo el canal `1544813161037963315`
- Solo reacciona a mensajes de SenZ V2 (`1409108089705332836`)
- Limpia el mensaje (mismo formato que la app)
- Lo muestra en la consola

## Próximos pasos

Cuando quieras, se puede conectar con:

- **ntfy.sh** → notificaciones push al celular
- Un archivo JSON público → la página lo lee automáticamente
- Webhook / API propia

## Estructura

```
bot/
├── index.js          ← Código principal
├── package.json
├── .env.example      ← Copia a .env y pon tu token
└── README.md
```
